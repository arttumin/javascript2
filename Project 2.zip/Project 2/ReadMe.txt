Arttu Minkkinen

Simple XMLHttpRequest code which retrieves data from 1. source (Making dropdown list in the process), compares it to 2nd and prints out data from 2nd source based on common ID

Data from 
https://www.finnkino.fi/xml/TheatreAreas/
https://www.finnkino.fi/xml/Schedule/

All the basic functions are working

Folders include index.html, scripts.js and styles.css files